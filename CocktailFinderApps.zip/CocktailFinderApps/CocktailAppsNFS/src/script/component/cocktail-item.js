class Cocktailltem extends HTMLElement {
  constructor() {
    super();
    this.shadowDOM = this.attachShadow({mode: 'open'});
  }
  set cocktail(cocktail) {
    this._cocktail = cocktail;
    this.render();
  }
 
  render() {
      this.shadowDOM.innerHTML =`
      <style>
      * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
      :host {
        display:grid;
        grid-template-columns: 35% auto;
        padding: 2em 1em;: grid;
        margin-bottom: 12px;
        box-shadow: 0 8px 8px 0 rgba(0, 0, 0, 0.2);
        background: #E8C4C4;
        border-radius: 10px;
        overflow: hidden;
      }
      
      .fan-art-cocktail {
        display: block;
        width: 100%;
        max-height: 1000px;
        object-fit: cover;
        object-position: center;
      }
      
      .cocktail-info {
        padding: 24px;
      }
      
      .cocktail-info > h3 {
        font-weight: lighter;
        font-size: 25px;
      }
      
      .cocktail-info > p {
        margin-top: 10px;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 10; 
      }
      </style>
      
      <img class="fan-art-cocktail" src="${this._cocktail.strDrinkThumb}" alt="Fan Art">
      <div class="cocktail-info">
       <h3>${this._cocktail.strDrink}</h3>
       <p>${this._cocktail.strCategory}</p>
       <p>Main Ingredients:${this._cocktail.strIngredient_1},${this._cocktail.strIngredient_2},${this._cocktail.strIngredient_3}</p><br>
       <h4>How To Make ?</h4>
       <p>${this._cocktail.strInstructions}</p>
      </div>`
      ;
  }
}

customElements.define('cocktail-item', Cocktailltem);
